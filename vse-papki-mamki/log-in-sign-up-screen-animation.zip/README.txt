A Pen created at CodePen.io. You can find this one at https://codepen.io/joshsorosky/pen/gaaBoB.

 Little form flow based on a design by www.100daysui.com/
Checkbox from codepen.io/CreativeJuiz/